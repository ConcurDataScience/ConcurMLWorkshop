Day 2 Part2:
Welcome to the ML Automation section of the ML Workshop. This morning we have gone through the process of how to create a trained model. However, in real life, you want easy and fast retraining cycle and automate the process once it has gone through initial training

## Pre-Requisites:
You should have created an AWS account.
You have checked out this github project to your local disk
If you missed the prior classes, please make sure that you have followed the general instruction in the github project home to
create the IAM role: ConcurMLWorkshopUse.
created your S3 bucket.
created and start your notebook instance (Make sure that the notebook was create in the us-west-2 region and assigned the above IAM role)
Doing these preparation is important because some of the steps such as creating the notebook instance can take upto 10 minutes.

## Key Objectives:
By the end of this section, you should have a good idea on

< FILL IN DETAILS >
HO-Hands On
P-Presentation Slides

## Post-Requisites:
After the session’s completion, you should have a good idea on how to run an automation pipleine using Sagemaker Estimators.

## Missed it ? Dont Worry

<FILL IN DETAILS>

## Cleanup Instruction:
The following resources are created after this session. Please follow the cleanup instructions to avoid incur any unnecessary charges on you.

<FILL IN DETAILS>
