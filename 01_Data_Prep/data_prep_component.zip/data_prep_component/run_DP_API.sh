#!/bin/bash

BUCKET_NAME=$1

# Check the variables
if [[ -z "${BUCKET_NAME}" ]]
then
    echo "Usage: ./run_DP_API.sh BUCKET_NAME"
  exit
fi
echo "Running DP API!"
echo "Getting todays available data from DP API!"
aws s3 cp s3://${BUCKET_NAME}/data_prep_component/DP_staging/upserts/ s3://${BUCKET_NAME}/data_prep_component/upserts/ --recursive
aws s3 cp s3://${BUCKET_NAME}/data_prep_component/DP_staging/deletes/ s3://${BUCKET_NAME}/data_prep_component/deletes/ --recursive
echo "Processing Finised!"